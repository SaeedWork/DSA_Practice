public class Linked_List {

    Node head;
    public class Node {
        int data;
        Node next;
        Node(int data){
            this.data = data;
        }
    }

    public void insertFirst(int data) {
        Node newNode = new Node(data);
        //Error Check
        if(head == null) {
            head = newNode;
            return;
        }

        //Insert at the beginning
        newNode.next = head;
        head = newNode;
    }

    public void insertLast(int data) {
        Node newNode = new Node(data);
        //Error Check
        if(head == null) {
            head = newNode;
            return;
        }
        //Traversal
        Node temp = head;
        while(temp.next != null) {
            temp = temp.next;
        }

        //Insert at the end
        temp.next = newNode;
    }

    public void insertAt(int data, int position){
        Node newNode = new Node(data);
        //Error Check
        if(head == null) {
            head = newNode;
            return;
        }

        //Traversal
        Node temp = head;
        for(int i = 1; i < position -1 ; i++) {
            temp = temp.next;
        }

        //Insert at the position
        newNode.next = temp.next;
        temp.next = newNode;
    }

    public void show() {
        Node temp = head;
        while(temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
    }
}
